FoundPhone-Studio asset bundle
Upload this ZIP to the root of L-LLeaf/FoundPhone-Studio as assets-upload.zip.
The build integration will unpack assets/ into public/assets/.
wallpaper.jpg: lock-screen/home wallpaper
gallery/: 11 supplied gallery photos (the source photo ZIP contained 11 files)
audio/day-by-day.m4a: supplied music audio
video/photos-clip.mov: supplied short video
avatars/: supplied avatar references
douban/group-reference.jpg: supplied Douban group reference image
